// ==UserScript==
// @name         YouTube - Catppuccin Mocha
// @namespace    yt-catppuccin-mocha
// @version      1.1
// @description  Phối màu Catppuccin Mocha cho YouTube (ghi đè biến màu của YouTube)
// @match        https://www.youtube.com/*
// @run-at       document-start
// @grant        GM_addStyle
// ==/UserScript==

(function () {
  'use strict';

  // Màu nhấn: rosewater, flamingo, pink, mauve, red, maroon, peach, yellow,
  //           green, teal, sky, sapphire, blue, lavender
  const ACCENT = 'mauve';

  // true = tắt hiệu ứng "Chế độ môi trường xung quanh" (vùng màu loang quanh video),
  //        vì với video tối nó thành một khối đen lớn
  const HIDE_AMBIENT = true;

  const C = {
    rosewater: '#f5e0dc', flamingo: '#f2cdcd', pink: '#f5c2e7', mauve: '#cba6f7',
    red: '#f38ba8', maroon: '#eba0ac', peach: '#fab387', yellow: '#f9e2af',
    green: '#a6e3a1', teal: '#94e2d5', sky: '#89dceb', sapphire: '#74c7ec',
    blue: '#89b4fa', lavender: '#b4befe',
    text: '#cdd6f4', subtext1: '#bac2de', subtext0: '#a6adc8',
    overlay2: '#9399b2', overlay1: '#7f849c', overlay0: '#6c7086',
    surface2: '#585b70', surface1: '#45475a', surface0: '#313244',
    base: '#1e1e2e', mantle: '#181825', crust: '#11111b',
  };
  const A = C[ACCENT] || C.mauve;
  const alpha = (hex, a) => hex + Math.round(a * 255).toString(16).padStart(2, '0');

  const vars = {
    // Nền
    '--yt-spec-base-background': C.base,
    '--yt-spec-raised-background': C.mantle,
    '--yt-spec-menu-background': C.mantle,
    '--yt-spec-general-background-a': C.base,
    '--yt-spec-general-background-b': C.base,
    '--yt-spec-general-background-c': C.mantle,
    '--yt-spec-snackbar-background': C.surface0,
    // Nền của thanh chip ở trang chủ và thanh trên cùng (mặc định là #0f0f0f)
    '--yt-spec-brand-background-solid': C.base,
    '--yt-spec-brand-background-primary': alpha(C.base, 0.98),
    '--yt-spec-brand-background-secondary': alpha(C.base, 0.95),
    '--yt-spec-frosted-glass-desktop': alpha(C.base, 0.9),
    '--yt-spec-inverted-background': C.text,
    '--yt-spec-additive-background': alpha(C.text, 0.08),
    '--yt-spec-badge-chip-background': C.surface0,
    '--yt-spec-button-chip-background-hover': C.surface1,
    '--yt-spec-mono-tonal-hover': C.surface1,
    '--yt-spec-10-percent-layer': alpha(C.text, 0.1),
    '--yt-spec-touch-response': C.text,
    '--yt-spec-outline': C.surface0,
    '--yt-spec-shadow': alpha(C.crust, 0.6),

    // Chữ
    '--yt-spec-text-primary': C.text,
    '--yt-spec-text-secondary': C.subtext0,
    '--yt-spec-text-disabled': C.overlay0,
    '--yt-spec-text-primary-inverse': C.crust,
    '--yt-spec-wordmark-text': C.text,
    '--yt-spec-selected-nav-text': C.text,

    // Icon
    '--yt-spec-icon-active-other': C.text,
    '--yt-spec-icon-inactive': C.subtext0,
    '--yt-spec-icon-disabled': C.overlay0,

    // Màu nhấn (link, nút, tab đang chọn)
    '--yt-spec-call-to-action': A,
    '--yt-spec-call-to-action-inverse': A,
    '--yt-spec-suggested-action': alpha(A, 0.18),
    '--yt-spec-brand-link-text': A,
    '--yt-spec-themed-blue': A,
    '--yt-spec-filled-button-focus-outline': A,
    '--yt-spec-call-to-action-button-focus-outline': A,
    '--yt-spec-brand-text-button-focus-outline': A,
    '--yt-spec-themed-green': C.green,
    '--yt-spec-error-indicator': C.red,
    '--yt-spec-red-indicator': C.red,

    // Ô tìm kiếm
    '--ytd-searchbox-background': C.mantle,
    '--ytd-searchbox-border-color': C.surface1,
    '--ytd-searchbox-legacy-border-color': C.surface1,
    '--ytd-searchbox-legacy-button-color': C.surface0,
    '--ytd-searchbox-legacy-button-border-color': C.surface1,
    '--ytd-searchbox-legacy-button-focus-color': C.surface1,
    '--ytd-searchbox-text-color': C.text,
  };

  const declarations = Object.entries(vars)
    .map(([k, v]) => `  ${k}: ${v} !important;`)
    .join('\n');

  GM_addStyle(`
html, html[dark], [dark], ytd-app {
${declarations}
}
html, body, ytd-app, #masthead-container, ytd-masthead, #background.ytd-masthead {
  background-color: ${C.base} !important;
  color-scheme: dark;
}
ytd-mini-guide-renderer, tp-yt-app-drawer #contentContainer, #guide-content {
  background-color: ${C.base} !important;
}

/* Thanh chip (Tất cả, Âm nhạc...) ở trang chủ */
ytd-feed-filter-chip-bar-renderer,
#chips-wrapper.ytd-feed-filter-chip-bar-renderer,
#frosted-glass, #frosted-glass.ytd-app {
  background: ${C.base} !important;
}

/* Ô tìm kiếm kiểu mới */
.ytSearchboxComponentInputBox,
.ytSearchboxComponentInputBoxDark {
  background-color: ${C.mantle} !important;
  border-color: ${C.surface1} !important;
}
.ytSearchboxComponentSearchButton,
.ytSearchboxComponentSearchButtonDark {
  background-color: ${C.surface0} !important;
  border-color: ${C.surface1} !important;
}
.ytSearchboxComponentInput { color: ${C.text} !important; }
.ytSearchboxComponentSuggestionsContainer,
.ytSearchboxComponentSuggestionsContainerDark {
  background-color: ${C.mantle} !important;
}

/* Khối đen quanh video: lớp "Chế độ môi trường xung quanh" (ambient mode) */
${HIDE_AMBIENT ? `#cinematics, #cinematics-container, ytd-watch-flexy #cinematics-container {
  display: none !important;
}` : ''}
ytd-watch-flexy, #columns.ytd-watch-flexy {
  background-color: transparent !important;
}

/* Thanh tiến trình video và chấm kéo */
.ytp-play-progress,
.ytp-swatch-background-color {
  background: ${A} !important;
}
.ytp-scrubber-button,
.ytp-scrubber-button.ytp-swatch-background-color {
  background: ${A} !important;
}
.ytp-settings-button.ytp-hd-quality-badge::after,
.ytp-chrome-controls .ytp-button[aria-pressed="true"]::after {
  background-color: ${A} !important;
}

/* Thanh "đã xem" trên ảnh thu nhỏ */
ytd-thumbnail-overlay-resume-playback-renderer #progress,
.ytThumbnailOverlayProgressBarHostWatchedProgressBarSegment {
  background: ${A} !important;
}

::selection { background: ${alpha(A, 0.35)}; color: ${C.text}; }
* { scrollbar-color: ${C.surface2} transparent; }
`);
})();