// ==UserScript==
// @name         Facebook - Catppuccin Mocha
// @namespace    fb-catppuccin-mocha
// @version      1.0
// @description  Phối màu Catppuccin Mocha cho Facebook (ghi đè biến màu của Facebook)
// @match        https://www.facebook.com/*
// @match        https://web.facebook.com/*
// @run-at       document-start
// @grant        GM_addStyle
// ==/UserScript==

(function () {
  'use strict';

  // Màu nhấn: rosewater, flamingo, pink, mauve, red, maroon, peach, yellow,
  //           green, teal, sky, sapphire, blue, lavender
  const ACCENT = 'mauve';

  const C = {
    rosewater: '#f5e0dc', flamingo: '#f2cdcd', pink: '#f5c2e7', mauve: '#cba6f7',
    red: '#f38ba8', maroon: '#eba0ac', peach: '#fab387', yellow: '#f9e2af',
    green: '#a6e3a1', teal: '#94e2d5', sky: '#89dceb', sapphire: '#74c7ec',
    blue: '#89b4fa', lavender: '#b4befe',
    text: '#cdd6f4', subtext1: '#bac2de', subtext0: '#a6adc8',
    overlay2: '#9399b2', overlay1: '#7f849c', overlay0: '#6c7086',
    surface2: '#585b70', surface1: '#45475a', surface0: '#313244',
    base: '#1e1e2e', mantle: '#181825', crust: '#11111b',
  };
  const A = C[ACCENT] || C.mauve;
  const alpha = (hex, a) => hex + Math.round(a * 255).toString(16).padStart(2, '0');

  const vars = {
    // Nền
    '--web-wash': C.mantle,
    '--wash': C.mantle,
    '--background-deemphasized': C.mantle,
    '--surface-background': C.base,
    '--card-background': C.base,
    '--card-background-flat': C.base,
    '--nav-bar-background': C.base,
    '--popover-background': C.base,
    '--messenger-card-background': C.base,
    '--comment-background': C.surface0,
    '--comment-footer-background': C.surface0,
    '--input-background': C.surface0,
    '--hero-banner-background': C.base,

    // Chữ
    '--primary-text': C.text,
    '--secondary-text': C.subtext0,
    '--section-header-text': C.subtext1,
    '--placeholder-text': C.overlay1,
    '--disabled-text': C.overlay0,
    '--blue-link': C.blue,
    '--event-date': C.red,

    // Viền, hover
    '--divider': C.surface0,
    '--media-inner-border': alpha(C.text, 0.1),
    '--media-outer-border': C.surface1,
    '--hover-overlay': alpha(C.text, 0.08),
    '--press-overlay': alpha(C.text, 0.12),
    '--non-media-pressed': alpha(C.text, 0.12),
    '--scroll-thumb': C.surface2,

    // Nút
    '--accent': A,
    '--fb-logo': A,
    '--primary-button-background': A,
    '--primary-button-pressed': alpha(A, 0.85),
    '--primary-button-text': C.crust,
    '--primary-button-icon': C.crust,
    '--primary-deemphasized-button-background': alpha(A, 0.18),
    '--primary-deemphasized-button-pressed': alpha(A, 0.28),
    '--primary-deemphasized-button-text': A,
    '--secondary-button-background': C.surface0,
    '--secondary-button-background-floating': C.surface0,
    '--secondary-button-pressed': C.surface1,
    '--secondary-button-text': C.text,
    '--secondary-button-stroke': C.surface1,
    '--disabled-button-background': C.surface0,
    '--disabled-button-text': C.overlay0,
    '--toggle-active-background': alpha(A, 0.18),
    '--toggle-active-text': A,
    '--toggle-active-icon': A,
    '--toggle-button-active-background': alpha(A, 0.18),

    // Trạng thái
    '--highlight-bg': alpha(A, 0.18),
    '--text-highlight': alpha(A, 0.3),
    '--new-notification-background': alpha(A, 0.1),
    '--hosted-view-selected-state': alpha(A, 0.18),
    '--notification-badge': C.red,
    '--positive': C.green,
    '--positive-background': alpha(C.green, 0.15),
    '--negative': C.red,
    '--negative-background': alpha(C.red, 0.15),
    '--warning': C.yellow,
    '--primary-web-focus-indicator': A,

    // Bóng đổ
    '--shadow-1': alpha(C.crust, 0.6),
    '--shadow-2': alpha(C.crust, 0.6),
    '--shadow-5': alpha(C.crust, 0.6),
    '--shadow-8': alpha(C.crust, 0.6),
    '--shadow-inset': alpha(C.text, 0.05),
  };

  const declarations = Object.entries(vars)
    .map(([k, v]) => `  ${k}: ${v} !important;`)
    .join('\n');

  GM_addStyle(`
:root, .__fb-dark-mode, .__fb-light-mode {
${declarations}
}
html, body { background-color: ${C.mantle} !important; color-scheme: dark; }
::selection { background: ${alpha(A, 0.35)}; color: ${C.text}; }
* { scrollbar-color: ${C.surface2} transparent; }
`);
})();