// ==UserScript==
// @name         Facebook - Ẩn bảng tin + nút Reels (giữ nguyên trang cá nhân)
// @namespace    fb-hide-feed
// @version      3.0
// @description  Ẩn News Feed ở trang chủ và nút Reels trên thanh menu. Trang cá nhân không bị ẩn nội dung gì.
// @match        https://www.facebook.com/*
// @match        https://web.facebook.com/*
// @run-at       document-start
// @grant        GM_addStyle
// ==/UserScript==

(function () {
  'use strict';

  // Các đường dẫn được coi là "trang feed". Muốn ẩn thêm thì thêm vào đây, vd: '/watch'
  const FEED_PATHS = ['/', '/home.php'];

  // true  = chỉ ẩn nút Reels khi đang ở trang feed
  // false = ẩn nút Reels ở mọi trang
  const REELS_ONLY_ON_FEED = false;

  const CLASS = 'fbhf-on-feed';
  const REELS_ATTR = 'data-fbhf-reels';
  const reelsScope = REELS_ONLY_ON_FEED ? `html.${CLASS} ` : '';

  // GM_addStyle không bị CSP của Facebook chặn như thẻ <style> tự chèn
  GM_addStyle(`
    ${reelsScope}[${REELS_ATTR}] { display: none !important; }

    html.${CLASS} div[role="main"] > * { display: none !important; }
    html.${CLASS} [role="feed"] { display: none !important; }
    html.${CLASS} div[role="main"]::before {
      content: "Bảng tin đã được ẩn";
      display: block;
      padding: 64px 16px;
      text-align: center;
      font-size: 17px;
      opacity: 0.6;
    }
  `);

  function isFeedPage() {
    const path = location.pathname.replace(/\/+$/, '') || '/';
    return FEED_PATHS.includes(path);
  }

  // Tìm nút Reels trên thanh menu phía trên.
  // Nút này trỏ tới /reel/ (thường kèm ?s=tab), còn video reel cụ thể là /reel/123... nên không bị đụng tới.
  function markReelsButton() {
    const links = document.querySelectorAll('a[href*="/reel"], a[aria-label="Reels"]');
    for (const a of links) {
      if (a.closest(`[${REELS_ATTR}]`)) continue;

      let path;
      try { path = new URL(a.href, location.origin).pathname; } catch { continue; }
      if (!/^\/reels?\/?$/.test(path)) continue;

      // Chỉ lấy nút nằm trên thanh menu trên cùng, bỏ qua mục Reels ở cột trái
      const inBanner = !!a.closest('[role="banner"]');
      const rect = a.getBoundingClientRect();
      const inTopBar = rect.height > 0 && rect.bottom <= 64;
      if (!inBanner && !inTopBar) continue;

      (a.closest('li') || a).setAttribute(REELS_ATTR, '');
    }
  }

  function update() {
    const root = document.documentElement;
    if (!root) return;
    const onFeed = isFeedPage();
    if (root.classList.contains(CLASS) !== onFeed) root.classList.toggle(CLASS, onFeed);
    if (document.body) markReelsButton();
  }

  // Facebook là SPA và hay vẽ lại thanh menu → kiểm tra định kỳ
  window.addEventListener('popstate', update);
  setInterval(update, 300);
  update();
})();