// ==UserScript==
// @name         YouTube: No Shorts, No Thumbnails (compact list)
// @namespace    quang.youtube.compact
// @version      1.3.1
// @description  Ẩn Shorts ở mọi nơi, ẩn thumbnail, hiển thị video dạng danh sách gọn chỉ còn avatar kênh
// @match        https://www.youtube.com/*
// @run-at       document-start
// @grant        none
// ==/UserScript==

(function () {
  'use strict';

  /* ---------------------------------------------------------------
   * 1. CSS
   * ------------------------------------------------------------- */
  const SHORTS_LINK = 'a[href^="/shorts/"]';

  const css = `
  /* ===== SHORTS ===== */
  /* Mục Shorts ở sidebar */
  ytd-guide-entry-renderer:has(a[title="Shorts"]),
  ytd-mini-guide-entry-renderer:has(a[title="Shorts"]),
  ytd-mini-guide-entry-renderer[aria-label="Shorts"],
  /* Kệ Shorts ở trang chủ, tìm kiếm, kênh, trang xem */
  ytd-rich-shelf-renderer[is-shorts],
  ytd-rich-section-renderer:has([is-shorts]),
  ytd-rich-section-renderer:has(${SHORTS_LINK}),
  ytd-reel-shelf-renderer,
  grid-shelf-view-model:has(${SHORTS_LINK}),
  ytm-shorts-lockup-view-model,
  ytm-shorts-lockup-view-model-v2,
  /* Video lẻ thực chất là Shorts */
  ytd-rich-item-renderer:has(${SHORTS_LINK}),
  ytd-video-renderer:has(${SHORTS_LINK}),
  ytd-grid-video-renderer:has(${SHORTS_LINK}),
  ytd-compact-video-renderer:has(${SHORTS_LINK}),
  ytd-playlist-video-renderer:has(${SHORTS_LINK}),
  yt-lockup-view-model:has(${SHORTS_LINK}),
  ytd-notification-renderer:has(${SHORTS_LINK}),
  /* Tab Shorts trên trang kênh */
  yt-tab-shape[tab-title="Shorts"],
  /* ===== PLAYABLES ===== */
  ytd-rich-section-renderer:has(a[href^="/playables"]),
  ytd-rich-shelf-renderer:has(a[href^="/playables"]),
  ytd-shelf-renderer:has(a[href^="/playables"]),
  ytd-rich-item-renderer:has(a[href^="/playables"]),
  ytd-guide-entry-renderer:has(a[href^="/playables"]),
  ytd-mini-guide-entry-renderer:has(a[href^="/playables"]),
  ytd-mini-game-card-view-model,
  /* ===== POSTS (bài đăng cộng đồng) ===== */
  ytd-rich-section-renderer:has(ytd-post-renderer),
  ytd-rich-section-renderer:has(ytd-backstage-post-thread-renderer),
  ytd-rich-section-renderer:has(a[href^="/post/"]),
  ytd-rich-shelf-renderer[is-post],
  ytd-shelf-renderer:has(ytd-post-renderer),
  ytd-rich-item-renderer:has(ytd-post-renderer),
  ytd-rich-item-renderer:has(a[href^="/post/"]),
  ytd-backstage-post-thread-renderer,
  ytd-post-renderer,
  yt-tab-shape[tab-title="Posts"],
  /* ===== QUẢNG BÁ YOUTUBE PREMIUM ===== */
  ytd-statement-banner-renderer,
  ytd-rich-section-renderer:has(ytd-statement-banner-renderer),
  ytd-rich-item-renderer:has(ytd-statement-banner-renderer),
  ytd-brand-video-singleton-renderer,
  ytd-rich-section-renderer:has(ytd-brand-video-singleton-renderer),
  ytd-brand-video-shelf-renderer,
  ytd-rich-section-renderer:has(ytd-brand-video-shelf-renderer),
  ytd-banner-promo-renderer,
  ytd-primetime-promo-renderer,
  ytd-mealbar-promo-renderer,
  yt-mealbar-promo-renderer,
  ytd-compact-promoted-item-renderer,
  ytd-rich-section-renderer:has(a[href*="/premium"]),
  ytd-rich-item-renderer:has(a[href*="/premium"]),
  #secondary yt-lockup-view-model:has(a[href*="/premium"]),
  #related yt-lockup-view-model:has(a[href*="/premium"]),
  #secondary ytd-ad-slot-renderer:has(a[href*="/premium"]),
  #related ytd-ad-slot-renderer:has(a[href*="/premium"]),
  /* Phần tử bị JS đánh dấu (chip lọc, tab, kệ theo tiêu đề...) */
  [data-noshorts-hidden] {
    display: none !important;
  }

  /* ===== THUMBNAIL ===== */
  ytd-thumbnail,
  ytd-playlist-thumbnail,
  ytd-moving-thumbnail-renderer,
  yt-thumbnail-view-model,
  yt-collection-thumbnail-view-model,
  yt-collections-stack,
  a[class*="lockup-view-model"][class*="__content-image"],
  div[class*="lockup-view-model"][class*="__content-image"],
  ytd-rich-grid-media #thumbnail,
  ytd-video-preview,
  #video-preview,
  .rich-thumbnail.skeleton-bg-color,
  /* Thumbnail gợi ý ở cuối video trong trình phát */
  .ytp-videowall-still-image,
  .ytp-ce-covering-image,
  .ytp-modern-videowall-still-image {
    display: none !important;
  }

  /* ===== BỐ CỤC DANH SÁCH GỌN ===== */
  /* Trang chủ / Kênh đăng ký: lưới -> 1 cột */
  ytd-rich-grid-renderer {
    --ytd-rich-grid-items-per-row: 1 !important;
    --ytd-rich-grid-posts-per-row: 1 !important;
  }
  ytd-rich-grid-row,
  ytd-rich-grid-row > #contents {
    display: contents !important;
  }
  ytd-rich-item-renderer {
    width: 100% !important;
    max-width: none !important;
    margin: 0 !important;
    padding: 8px 0 !important;
    border-bottom: 1px solid var(--yt-spec-10-percent-layer, rgba(128,128,128,.2));
  }
  ytd-rich-item-renderer #details,
  ytd-rich-grid-media #details {
    margin-top: 0 !important;
  }

  /* Thanh chip (All, Music, Gaming...) canh giữa, thẳng hàng với danh sách */
  ytd-feed-filter-chip-bar-renderer #chips-content {
    flex: 0 0 auto !important;
    align-self: center !important;
    height: auto !important;
    width: 100% !important;
    max-width: var(--compact-list-width, 716px) !important;
    min-width: 0 !important;
    margin: 0 auto !important;
    padding-left: 0 !important;
    padding-right: 0 !important;
  }

  /* Kết quả tìm kiếm, lịch sử, playlist */
  ytd-video-renderer,
  ytd-playlist-renderer,
  ytd-radio-renderer,
  ytd-playlist-video-renderer {
    margin: 0 !important;
    padding: 8px 0 !important;
    border-bottom: 1px solid var(--yt-spec-10-percent-layer, rgba(128,128,128,.2));
  }
  ytd-video-renderer .text-wrapper {
    max-width: none !important;
  }

  /* Lưới video trên trang kênh */
  ytd-grid-video-renderer {
    width: 100% !important;
    margin: 0 !important;
    padding: 8px 0 !important;
    border-bottom: 1px solid var(--yt-spec-10-percent-layer, rgba(128,128,128,.2));
  }

  /* Cột gợi ý ở trang xem video */
  ytd-compact-video-renderer,
  ytd-compact-playlist-renderer,
  ytd-compact-radio-renderer,
  #secondary yt-lockup-view-model,
  #related yt-lockup-view-model {
    margin: 0 !important;
    padding: 6px 0 !important;
    border-bottom: 1px solid var(--yt-spec-10-percent-layer, rgba(128,128,128,.2));
  }

  /* Cột gợi ý: bỏ khoảng trống thumbnail để lại */
  #secondary yt-lockup-view-model > div,
  #related yt-lockup-view-model > div,
  #secondary ytd-compact-video-renderer #dismissible,
  #related ytd-compact-video-renderer #dismissible {
    display: block !important;
  }
  #secondary yt-lockup-view-model [class*="lockup-view-model"][class*="__metadata"],
  #related yt-lockup-view-model [class*="lockup-view-model"][class*="__metadata"],
  #secondary ytd-compact-video-renderer .details,
  #related ytd-compact-video-renderer .details {
    margin-left: 0 !important;
    padding-left: 0 !important;
    width: 100% !important;
  }

  /* Lockup kiểu mới: phần chữ chiếm hết chiều ngang */
  yt-lockup-view-model [class*="lockup-view-model"][class*="__metadata"] {
    flex: 1 1 auto !important;
    max-width: none !important;
  }
  `;

  function injectStyle() {
    if (document.getElementById('noshorts-nothumb-style')) return;
    const style = document.createElement('style');
    style.id = 'noshorts-nothumb-style';
    style.textContent = css;
    (document.head || document.documentElement).appendChild(style);
  }
  injectStyle();
  // YouTube đôi khi thay <head>; chèn lại nếu mất
  document.addEventListener('DOMContentLoaded', injectStyle);

  /* ---------------------------------------------------------------
   * 2. Chuyển /shorts/ID -> /watch?v=ID
   * ------------------------------------------------------------- */
  function shortsToWatch(pathname) {
    const m = /^\/shorts\/([\w-]{5,})/.exec(pathname);
    return m ? '/watch?v=' + m[1] : null;
  }

  function redirectIfShorts() {
    const target = shortsToWatch(location.pathname);
    if (target) location.replace(target);
  }
  redirectIfShorts();
  window.addEventListener('yt-navigate-start', redirectIfShorts, true);
  window.addEventListener('yt-navigate-finish', redirectIfShorts, true);
  window.addEventListener('popstate', redirectIfShorts, true);

  // Link Shorts còn sót (mô tả, bình luận...) -> mở bằng trình phát thường
  document.addEventListener(
    'click',
    (e) => {
      if (e.button !== 0 || e.ctrlKey || e.metaKey || e.shiftKey) return;
      const a = e.target.closest && e.target.closest('a[href*="/shorts/"]');
      if (!a) return;
      let url;
      try {
        url = new URL(a.href, location.origin);
      } catch {
        return;
      }
      const target = shortsToWatch(url.pathname);
      if (!target) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      location.href = target;
    },
    true
  );

  /* ---------------------------------------------------------------
   * 3. Ẩn các phần tử chỉ nhận ra được qua chữ "Shorts"
   *    (chip lọc tìm kiếm, tab kênh, mục sidebar không có title)
   * ------------------------------------------------------------- */
  const TEXT_TARGETS = [
    'yt-chip-cloud-chip-renderer',
    'chip-view-model',
    'yt-tab-shape',
    'tp-yt-paper-tab',
    'ytd-guide-entry-renderer',
    'ytd-mini-guide-entry-renderer',
  ].join(',');

  // Nhãn (tab, chip, mục sidebar) cần ẩn - so khớp chính xác
  const HIDDEN_LABELS = new Set([
    'Shorts',
    'Posts',
    'Bài đăng',
    'Playables',
    'YouTube Playables',
  ]);

  // Tiêu đề kệ/khối cần ẩn - thêm regex vào đây nếu giao diện dùng ngôn ngữ khác
  const HIDDEN_SECTION_TITLES = [
    /playables/i,
    /^get more from memberships/i,
    /^latest (youtube )?posts/i,
    /youtube premium/i,
    /premium free/i,
  ];

  const SECTION_TARGETS = [
    'ytd-rich-section-renderer',
    'ytd-rich-shelf-renderer',
    'ytd-shelf-renderer',
    'ytd-horizontal-card-list-renderer',
    'ytd-statement-banner-renderer',
    'ytd-brand-video-singleton-renderer',
    'grid-shelf-view-model',
  ].join(',');

  function hideByText() {
    document.querySelectorAll(TEXT_TARGETS).forEach((el) => {
      if (el.hasAttribute('data-noshorts-hidden')) return;
      if (HIDDEN_LABELS.has(el.textContent.trim())) {
        el.setAttribute('data-noshorts-hidden', '');
      }
    });

    document.querySelectorAll(SECTION_TARGETS).forEach((el) => {
      if (el.hasAttribute('data-noshorts-hidden')) return;
      const titleEl = el.querySelector('#title, #title-text, h2, h3, [role="heading"]');
      const text = (titleEl ? titleEl.textContent : el.textContent.slice(0, 150)).trim();
      if (text && HIDDEN_SECTION_TITLES.some((re) => re.test(text))) {
        el.setAttribute('data-noshorts-hidden', '');
      }
    });
  }

  let scheduled = false;
  function schedule() {
    if (scheduled) return;
    scheduled = true;
    setTimeout(() => {
      scheduled = false;
      hideByText();
    }, 300);
  }

  function startObserver() {
    hideByText();
    new MutationObserver(schedule).observe(document.documentElement, {
      childList: true,
      subtree: true,
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', startObserver);
  } else {
    startObserver();
  }
})();